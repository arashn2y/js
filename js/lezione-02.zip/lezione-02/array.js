/**
 * Array con i dati
 */
export const arrayData = [
    "Marco Rossi",
  "Luca Bianchi",
  "Sara Verdi",
  "Giulia Rossi",
  "Francesco Neri",
  "Luca Verdi",
  "Marco Bianchi",
  "Elena Russo",
  "Maria Neri",
  "Giulia Russo",
  "Francesco Verdi",
  "Sara Bianchi",
  "Luca Rossi",
  "Marco Neri",
  "Elena Rossi",
  "Maria Bianchi",
  "Giulia Verdi",
  "Francesco Bianchi",
  "Sara Russo",
  "Elena Verdi"
]